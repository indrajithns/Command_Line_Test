Command Line Argument To Execute The Linux Project01 For Command Line Test Quiz Application
    
Command to Run Quiz Application: bash test.sh

This will give the required output
